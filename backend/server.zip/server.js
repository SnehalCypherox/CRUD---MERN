var express = require("express");
var mongoose = require("mongoose");
var cors = require("cors");
var bodyParser = require("body-parser");
let dbConfig = require("./database/db");

// Express Route
const studentRoute = require("../backend/routes/student.route");

// mongoose.connect(
//     dbConfig.db,
//     {
//         useNewUrlParser: true,
//         useUnifiedTopology: true,
//     },
//     () => {
//         console.log("Database connected");
//     }
// );

async function main() {
    const connectionOptions = {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }

    try {
        await mongoose.connect(dbConfig.db, connectionOptions)
        console.log(`Connected to MongoDB`)
    } catch (err) {
        console.log(`Couldn't connect: ${err}`)
    }
}

const app = express();
app.use(bodyParser.json());
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
);
app.use(cors());
app.use("/students", studentRoute);

// PORT
const port = process.env.PORT || 5000;
app.listen(port, () => {
    console.log('Server started')
})

// 404 Error
app.use((req, res) => {
    res.status(404).send("Error 404!");
});

// ===========================================================
// const express = require('express')
// const mongoose = require('mongoose')
// const url = 'mongodb://localhost:27017/'

// const app = express()

// mongoose.connect(url, {useNewUrlParser:true,useUnifiedTopology: true})
// const con = mongoose.connection

// con.on('open', () => {
//     console.log('connected...')
// })




// mongoose
//     .connect( url, {
//         dbName: crud,
//     } )
//     .then( () =>
//     {
//         console.log( 'mongoose connected.' );
//     } )
//     .catch( err => console.log( err.message ) );


// mongoose.connection.on( 'error', err =>
// {
//     console.log( err.message );
// } );

// mongoose.connection.on( 'disconnected', () =>
// {
//     console.log( 'Mongoose is disconnected' );
// } );

// process.on( 'SIGINT', async () =>
// {
//     await mongoose.connection.close();
//     process.exit( 0 );
// } );


// app.use(express.json())

// const studentRoute = require("../backend/routes/student.route");
// app.use("/students", studentRoute);

// app.listen(9000, () => {
//     console.log('Server started')
// })